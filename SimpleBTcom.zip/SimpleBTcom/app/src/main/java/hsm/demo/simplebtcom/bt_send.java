package hsm.demo.simplebtcom;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.SimpleTimeZone;
import java.util.UUID;

import javax.crypto.Mac;

public class bt_send implements Runnable {

    Context m_context;
    String TAG="BTComDemo";

    String MacAddress;
    private BluetoothSocket mSocket=null;
    private InputStream mInStream=null;
    private OutputStream mOutStream=null;
    private static final UUID UUID_SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothDevice mDevice=null;
    private BluetoothAdapter mBluetoothAdapter=null;

    MainActivity mainActivity;

    public bt_send(MainActivity activity, Context context, String sMac){
        m_context=context;
        MacAddress=sMac;
        mainActivity=activity;
    }

    public void run(){
        final String mac= MacAddress;
        connectAndSend(mac, csimQuery());
    }

    final byte[] csimQuery(){
        byte[] buf;
        String sBuf = "!U1\r\nVERSION\r\n";
        Charset charset = Charset.forName("UTF-8");
        ByteBuffer byteBuffer = charset.encode(sBuf);
        return byteBuffer.array();
    }

    void connectAndSend(final String sMacAddr, final byte[] sendBytes){

        BluetoothDevice device;
        try {
            // Get local Bluetooth adapter
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            device = mBluetoothAdapter.getRemoteDevice(sMacAddr);
            mainActivity.addLog("BT device found");
        }catch (Exception e){
            Toast.makeText(m_context,"Invalid BT MAC address", Toast.LENGTH_LONG);
            mainActivity.addLog("Failed to get BT device by Mac address!");
            device=null;
        }

        byte[] buf=new byte[200];
        int maxTry=10;
        int iTry=0;
        if (device != null) {
            addLog("connecting to " + sMacAddr);
            mainActivity.addLog("connecting to " + sMacAddr + " ...");
            try {
                addLog("createInsecureRfcommSocketToServiceRecord");
                mSocket = device.createInsecureRfcommSocketToServiceRecord(UUID_SPP);
                //tmp = device.createRfcommSocketToServiceRecord(UUID_SPP);
                mSocket.connect();
                mainActivity.addLog("BT socket connected");
                // Get the BluetoothSocket input and output streams
                try {
                    mInStream = mSocket.getInputStream();
                    mOutStream = mSocket.getOutputStream();
                    mOutStream.write(sendBytes);
                    mOutStream.flush();
                    Log.d(TAG, "write done");
                    mainActivity.addLog("CSim version requested");
                    String sIn = "";
                    do {

                        int iCnt = mInStream.read(buf);
                        String s = new String(buf, 0, iCnt);
                        Log.d(TAG, "received: " + s);
                        sIn += s;
                        if (sIn.endsWith("\r\n")) {
                            Log.d(TAG, "receive complete: "+ sIn);
                            mainActivity.addLog("Received: "+ sIn);
                            break;
                        }
                        iTry++;
                        Thread.sleep(500);
                    }while(iTry<maxTry);
                    mInStream.close();
                    mOutStream.close();
                    mSocket.close();
                    mainActivity.addLog("BT socket closed");

                } catch (IOException e) {
                    Log.e(TAG, "temp sockets not created", e);
                    mainActivity.addLog("Failed to connect to BT socket!");
                }

            } catch (IOException e) {
                Log.e(TAG, "create() failed", e);
                mainActivity.addLog("socket create failed!");
            } catch (InterruptedException e) {
                Log.e(TAG, "create() failed", e);
                mainActivity.addLog("socket stream interrupted!");
            }
            // This is a blocking call and will only return on a
            // successful connection or an exception

        } else {
            addLog("unknown remote device!");
            mainActivity.addLog("unknown remote device!");
        }


    }
    void addLog(String s){
        Log.d(TAG, s);
    }


}
